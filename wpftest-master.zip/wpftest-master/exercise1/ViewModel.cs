﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exercise1
{
    public class ViewModel : INotifyPropertyChanged
    {
        public event PropertyChangedEventHandler PropertyChanged;

        private Double height;
        public Double Height
        {
            get
            {
                return this.height;
            }

            set
            {
                height = value;
                OnPropertyChanged("Height");
            }
        }
        private Double width;
        public Double Width
        {
            get
            {
                return this.width;
            }

            set
            {
                width = value;
                OnPropertyChanged("Width");
            }
        }
        private string text;
        public string Text
        {
            get
            {
                return this.text;
            }

            set
            {
                text = value;
                OnPropertyChanged("Text");
            }
        }

        public void OnPropertyChanged(string property)
        {
            if (PropertyChanged != null)
            {
                PropertyChanged(this, new PropertyChangedEventArgs(property));
            }
        }
    }
}
