﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace exercise2
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        public MainWindow()
        {
            InitializeComponent();
        }

        DispatcherTimer t = new DispatcherTimer();

        private void Window_Activated(object sender, EventArgs e)
        {
            t.Interval = TimeSpan.FromSeconds(1);
            t.Tick += (senderT, eT) =>
            {
                myTextBlock.Text = (int.Parse(myTextBlock.Text) - 1).ToString();
                if (myTextBlock.Text == 0.ToString())
                {
                    t.Stop();
                    TimerState = 2;
                    MessageBox.Show("You didn't answer in time", "Time ran out", MessageBoxButton.OK, MessageBoxImage.Asterisk);
                    this.Close();
                }
                else if(myTextBlock.Text == 15.ToString())
                {
                    myTextBlock.Foreground = Brushes.Red;
                }
                else
                    TimerState = 0;
            };
            t.Start();
        }

        public int TimerState
        {
            get { return (int)GetValue(TimerStateProperty); }
            set { SetValue(TimerStateProperty, value); }
        }

        public static readonly DependencyProperty TimerStateProperty =
            DependencyProperty.Register("TimerState", typeof(int), typeof(MainWindow), new PropertyMetadata(0));

        public void WrongClick(string text)
        {
            TimerState = 2;
            t.Stop();
            answerTextBlock.Text = text.ToString();
            myTextBlock.Text = 0.ToString();

            MessageBox.Show("Looks like the wrong answer", "Wrong Answer", MessageBoxButton.OK, MessageBoxImage.Asterisk);
            this.Close();
        }

        private void RightClick(string text)
        {
            TimerState = 1;
            t.Stop();
            answerTextBlock.Text = text.ToString();
            myTextBlock.Text = 0.ToString();
            MessageBox.Show("You chose the correct answer!", "Congratulations", MessageBoxButton.OK, MessageBoxImage.Asterisk);
            this.Close();
        }

        private void btn360_Click(object sender, RoutedEventArgs e)
        {
            WrongClick(btn360.Content.ToString());
        }

        private void btn416_Click(object sender, RoutedEventArgs e)
        {
            WrongClick(btn416.Content.ToString());
        }

        private void btn166_Click(object sender, RoutedEventArgs e)
        {
            WrongClick(btn166.Content.ToString());
        }

        private void btn216_Click(object sender, RoutedEventArgs e)
        {
            RightClick(btn216.Content.ToString());
        }
    }
}
